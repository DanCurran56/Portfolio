from ast import Lambda, Not, Or, Str
from pickle import TRUE
import random
import time

cut_type_array = []

class sheet:
    def __init__(self, sheet_num, X_dist, Y_dist):
        self.sheet_num = sheet_num
        self.X_dist = X_dist
        self.Y_dist = Y_dist
        self.Area = X_dist * Y_dist
        self.remaining_area = X_dist * Y_dist
        self.cuts = []
    
class cut_type:
    def __init__(self, cut_type_ID, X_dist, Y_dist, Required_Quant):
        self.cut_type_ID = cut_type_ID
        self.X_dist = X_dist
        self.Y_dist = Y_dist
        self.Area = X_dist * Y_dist
        self.Required_Quant = Required_Quant

class cut:
    def __init__(self, cut_Num, cut_type_id, cut_OriginX, cut_OriginY):
        self.cut_Num = cut_Num
        self.cut_type_id = cut_type_id
        self.cut_OriginX = cut_OriginX
        self.cut_OriginY = cut_OriginY

def set_cut_values():
    cut_type_array.clear()

    cut_type0 = cut_type("0", 10, 10, 2)
    cut_type1 = cut_type("1", 15, 5, 2)
    cut_type2 = cut_type("2", 5, 10, 3)
    cut_type3 = cut_type("3", 5, 5, 5)
    cut_type4 = cut_type("4", 3, 3, 4)
    cut_type5 = cut_type("5", 2, 2, 8)
    cut_type6 = cut_type("6", 4, 2, 5)
    cut_type7 = cut_type("7", 1, 5, 10)
    cut_type8 = cut_type("8", 4, 4, 5)

    cut_type_array.append(cut_type0)
    cut_type_array.append(cut_type1)
    cut_type_array.append(cut_type2)
    cut_type_array.append(cut_type3)
    cut_type_array.append(cut_type4)
    cut_type_array.append(cut_type5)
    cut_type_array.append(cut_type6)
    cut_type_array.append(cut_type7)
    cut_type_array.append(cut_type8)




def solution_generation():
    set_cut_values()
    solution = []

    sheet0 = sheet("0", 20, 15)
    solution.append(sheet0)

    current_sheet_number = 0
    current_cut = 0

    number_of_cuts_made = 0

    continue_cutting = False

    while True:
        continue_cutting = False
        cut_select_limit = 0
        while True:
            chosen_cut_type_number = random.randrange(9)
            #print(chosen_cut_type_number)
            
            chosen_cut_type = cut_type_array[chosen_cut_type_number]
            current_sheet = solution[current_sheet_number]

            #print(chosen_cut_type.Required_Quant)

            if chosen_cut_type.Required_Quant == 0:
                continue

            if chosen_cut_type.Area > current_sheet.remaining_area:
                cut_select_limit += 1
                #print("cut select limit: ", cut_select_limit)
                if cut_select_limit > 15:
                    #print("new sheet")
                    current_sheet_number += 1
                    locals()["sheet" + str(current_sheet_number)] = sheet(str(current_sheet_number), 20, 15)
                    solution.append(locals()["sheet" + str(current_sheet_number)])
                    cut_select_limit = 0
                    #print(solution)
                continue
            else:
                cut_select_limit = 0
                break

        if len((solution[current_sheet_number]).cuts) == 0:
            #print("first cut made")
            cut0 = cut(current_cut, chosen_cut_type_number, 0, 0)
            (solution[current_sheet_number]).cuts.append(cut0)
            (cut_type_array[chosen_cut_type_number].Required_Quant) -= 1
            number_of_cuts_made += 1
            current_cut += 1
            #print(number_of_cuts_made)
        else:
            place_attempts = 0
            while True:
                can_place = True
                cut_startX = random.randrange(solution[current_sheet_number].X_dist)
                cut_startY = random.randrange(solution[current_sheet_number].Y_dist)

                for i in solution[current_sheet_number].cuts:
                    for x in range(0, (cut_type_array[chosen_cut_type_number]).X_dist, 1):
                        for y in range(0, (cut_type_array[chosen_cut_type_number]).Y_dist, 1):
                            if (i.cut_OriginX < (cut_startX + x) < (i.cut_OriginX + (cut_type_array[i.cut_type_id].X_dist))):
                                if (i.cut_OriginY < (cut_startY + y) < (i.cut_OriginY + (cut_type_array[i.cut_type_id].Y_dist))):
                                    can_place = False
                                    place_attempts +=1

                if place_attempts > 15:
                    #print("no space for cut")
                    break

                if can_place:
                    place_attempts = 0
                    #print("cut made")
                    break

            if can_place:
                locals()["cut" + str(current_cut)] = cut(current_cut, chosen_cut_type_number, cut_startX, cut_startY)
                (solution[current_sheet_number]).cuts.append(locals()["cut" + str(current_cut)])
                (cut_type_array[chosen_cut_type_number].Required_Quant) -= 1
                current_sheet.remaining_area -= chosen_cut_type.Area
                number_of_cuts_made += 1
                current_cut += 1
                #print(number_of_cuts_made)

        for x in range(len(cut_type_array)):
            check_cut = cut_type_array[x]
            if (check_cut.Required_Quant > 0):
                continue_cutting = True

        if continue_cutting == False:
            print(solution)
            return solution

def population_genertion(pop_size):
    population = [];
    for x in range(pop_size):
        population.append(solution_generation())
    return population


def genetic_algorithm(pop_size, gen_limit, mutation_rate):
    start = time.time()
    
    population = population_genertion(pop_size)

    GA_start = time.time()
    best_solution = iterator(pop_size, population, gen_limit, mutation_rate)
    GA_end = time.time()

    print_GA_results(pop_size, best_solution, gen_limit, population)

    end = time.time()
    print("total execution time: ", (end - start), " seconds")
    print("GA runtime: ", (GA_end - GA_start), " seconds")

    return best_solution


def iterator(pop_size, population, gen_limit, mutation_rate):
    best_solution = population[0]

    for x in range(gen_limit):
        #print("new generation")
        
        population, best_solution = ranking_function(population, best_solution, x)
        print(fitness_function_waste_material(best_solution), " ", fitness_function_waste_material(population[int((len(population) / 2))]), " ", fitness_function_waste_material(population[-1]), " ", fitness_function_waste_genNum_product(best_solution, x), " ", fitness_function_waste_genNum_product(population[int((len(population) / 2))], x), " ", fitness_function_waste_genNum_product(population[-1], x), " ", fitness_function_max_sheet_waste(best_solution), " ", fitness_function_max_sheet_waste(population[int((len(population) / 2))]), " ", fitness_function_max_sheet_waste(population[-1]))
        population = breeding_function(population, pop_size, mutation_rate)

    
    #print("Number of generations: ", x)
    return best_solution



def breeding_function(population, pop_size, mutation_rate):
    new_population = []
    weight_values = []

    for x in range(len(population)):
        weight_values.append(len(population) - x)

    for x in population:
        parent1 = x
        parent2 = random.choice(population) #, weights= weight_values, k=1)
        child = mating_function(parent1, parent2)
        child = mutation_function(child, mutation_rate)
        new_population.append(child)

    if len(new_population) < pop_size:
        for x in range(len(new_population), pop_size):
            new_population.append(solution_generation())

    return new_population


def mating_function(parent1, parent2):
    child = []
    parent1_cuts = 0
    parent2_cuts = 0
    child_cuts_made = 0

    #sheet0 = sheet("0", 20, 15)
    #child.append(sheet0)

    for i in parent1: #count total cuts in parent 1
        parent1_cuts += len(i.cuts)

    for j in parent2: #count total cuts in parent 2
        parent2_cuts += len(j.cuts)

    if parent1_cuts <= parent2_cuts:
        cut_point = random.randrange(parent1_cuts)
    else:
        cut_point = random.randrange(parent2_cuts)

    for x in parent1:
        if (child_cuts_made + len(x.cuts)) < cut_point:
            child.append(x)
            child_cuts_made += len(x.cuts)
        else:
            new_sheet = sheet(int(x.sheet_num) +1, 20, 15)
            child.append(new_sheet)
            cut_to_add = 0
            while child_cuts_made < cut_point:
                child[-1].cuts.append(x.cuts[cut_to_add])
                child_cuts_made +=1
                cut_to_add +=1
            last_sheet_from_parent1 = x.sheet_num
            break

    for y in range(int(last_sheet_from_parent1), len(parent2)):
        child.append(parent2[y])

    child = check_cuts(child)

    return child

def check_cuts(child):
    set_cut_values()

    #print("checking child")

    for current_sheet in child:
        for current_cut in current_sheet.cuts:
            if (cut_type_array[int(current_cut.cut_type_id)]).Required_Quant > 0:
                (cut_type_array[int(current_cut.cut_type_id)]).Required_Quant -= 1
            else:
                #print("removed cut")
                current_sheet.cuts.remove(current_cut)

        if len(current_sheet.cuts) == 0:
            child.remove(current_sheet)
    
    for z in cut_type_array:
        if z.Required_Quant > 0:
            #last_cut_num = child[-1].cuts[-1].cut_Num
            if child[-1].remaining_area < z.Area:
                locals()["sheet" + str(int(child[-1].sheet_num) + 1)] = sheet(str(int(child[-1].sheet_num) + 1), 20, 15)
                child.append(locals()["sheet" + str(int(child[-1].sheet_num) + 1)])
                cut0 = cut("0", z.cut_type_ID, 0, 0)
                child[-1].cuts.append(cut0)
            else:
                place_attempts = 0
                while True:
                    can_place = True
                    cut_startX = random.randrange(child[-1].X_dist)
                    cut_startY = random.randrange(child[-1].Y_dist)

                    for i in child[-1].cuts:
                        for x in range(0, z.X_dist, 1):
                            for y in range(0, z.Y_dist, 1):
                                if (i.cut_OriginX < (cut_startX + x) < (i.cut_OriginX + (cut_type_array[int(i.cut_type_id)].X_dist))):
                                    if (i.cut_OriginY < (cut_startY + y) < (i.cut_OriginY + (cut_type_array[int(i.cut_type_id)].Y_dist))):
                                        can_place = False
                                        place_attempts +=1

                    if place_attempts > 15:
                        #print("no space for cut")
                        place_attempts = 0
                        locals()["sheet" + str(int(child[-1].sheet_num) + 1)] = sheet(str(int(child[-1].sheet_num) + 1), 20, 15)
                        child.append(locals()["sheet" + str(int(child[-1].sheet_num) + 1)])
                        cut0 = cut("0", z.cut_type_ID, 0, 0)
                        child[-1].cuts.append(cut0)
                        break
                        

                    if can_place:
                        #print("cut placed")
                        locals()["cut" + str(len(child[-1].cuts))] = cut(len(child[-1].cuts), z.cut_type_ID, cut_startX, cut_startY)
                        (child[-1]).cuts.append(locals()["cut" + str(len(child[-1].cuts))])
                        (z.Required_Quant) -= 1
                        current_sheet.remaining_area -= cut_type_array[int(z.cut_type_ID)].Area
                        break
    
    for current_sheet in child:
        if len(current_sheet.cuts) <= 0:
            child.remove(current_sheet)

    return child

def mutation_function(child, mutation_rate):
    i = random.randrange(0, mutation_rate)

    if i == 0:
        mutating_sheet_num = random.randrange(0, len(child))
        mutating_cut_num = random.randrange(0, len(child[mutating_sheet_num].cuts))
        child[mutating_sheet_num].cuts.remove(child[mutating_sheet_num].cuts[mutating_cut_num])
        check_cuts(child)
    return child



def ranking_function(population, current_best_solution, gen_number):
    
    #best_solution_score = fitness_function_waste_material(current_best_solution) #call fitness function here
    
    #best_solution_score = fitness_function_waste_genNum_product(current_best_solution, gen_number)
    
    best_solution_score = fitness_function_max_sheet_waste(current_best_solution)

    sorted_population = []
    ranking = []

    for individual in population:
        score = 0
        #score = fitness_function_waste_material(individual) #call fitness function here
        #score = fitness_function_waste_genNum_product(individual, gen_number)
        score = fitness_function_max_sheet_waste(individual)
        ranking.append(int(score))

        if score > best_solution_score:
            best_solution_score = score
            current_best_solution = individual

    #sorted_ranking = sorted(ranking)
    #basic_list = [0,1,2,11,4,5,6,7,8,9]
    #basic_ranking_zip = zip(ranking, basic_list)
    #sorted_basic_ranking_zip = sorted(basic_ranking_zip)
    

    #ranked_population = zip(ranking, population)
    #list_ranked_population = list(ranked_population)
    #sorted_list_population = sorted(list_ranked_population, key=lambda x: (x[0]), reverse=True)

    sorted_population = [x for _,x in sorted(zip(ranking, population), key=lambda x: (x[0]), reverse=True)]

    return sorted_population, current_best_solution

def fitness_function_waste_material(individual):
    waste = 0.0
    total_area = 0.0

    for x in individual:
        waste += float(x.remaining_area)
        total_area += float(x.Area)

    waste_percentage = (waste/total_area) * 100.0

    score = 100.0 - waste_percentage

    return score

def fitness_function_waste_genNum_product(individual, gen_number):
    
    if gen_number > 0:
        score = fitness_function_waste_material(individual) * float(gen_number)
    else:
        score = fitness_function_waste_material(individual)
    return score

def fitness_function_max_sheet_waste(individual):
    max_sheet_waste = 0
    max_sheet_waste_percentage = 0
    
    for each_sheet in individual:
        if each_sheet.remaining_area > max_sheet_waste:
            max_sheet_waste = each_sheet.remaining_area
            max_sheet_waste_percentage = each_sheet.remaining_area / each_sheet.Area
    
    sheet_used = 100 - max_sheet_waste_percentage

    return sheet_used

def fitness_function4():
    pass

def print_GA_results(pop_size, best_solution, gen_limit, population):
    print("Best Solution: ", best_solution)
    print("Best Solution Fitness Score (waste material): ", fitness_function_waste_material(best_solution))
    print("Best Solution Fitness Score (waste x gen number): ", fitness_function_waste_genNum_product(best_solution, (gen_limit - 1)))
    print("Best Solution Fitness Score (waste of worst sheet): ", fitness_function_max_sheet_waste(best_solution))
    print("Population size: ", pop_size)
    print("Generation limit: ", gen_limit)

#genetic_algorithm(20, 20, 40)
genetic_algorithm(10, 10, 20)
#solution_generation()