import random
import math
import copy
import xlrd
import re

#empty variables declared to be used globally
#Maze = None
#df = None #df stands for data file
Start_cell = []
Target_cell = []

Correct_solution = ["D","D","D","D","D","R","D","D","D","R","R","R","R","U","R","R","U","U","U","U","L","L","U","U","R","R","R","R","R","R","R","R","R","R","R","R","R","D","D","L","L","L","D","D","D","L","L","D","D","R","R","R","R","R","D"]


def student_details():
    
    student_id = 17036602;
    student_username = "Daniel Curran";
    
    return student_id, student_username

def get_excel_maze(maze_address):
    #import maze from excel file
    df = xlrd.open_workbook(maze_address)
    Maze = df.sheet_by_index(0)
    return Maze
    
    
#get_excel_maze()
#print(Maze.cell_value(0,1))

def Read_cell(Cell_X_Coor, Cell_Y_Coor,selected_maze):
    #identify the contents of the cell (what directions of travel are possible from cell))
    Cell_Contents = selected_maze.cell_value(Cell_X_Coor,Cell_Y_Coor)

    return Cell_Contents
    

def Identify_start_end(selected_maze):
    #identify and label start/end cells
    global Start_cell
    global Target_cell
    
    for i in range(selected_maze.ncols - 1):
        Cell_Contents = Read_cell(0,i,selected_maze)
        if("S" in Cell_Contents):
            print("Assign Start_cell")
            Start_cell = [0,i]
            break
    
    for i in range(selected_maze.ncols):
        Cell_Contents = Read_cell(selected_maze.nrows -1,i,selected_maze)
        if("E" in Cell_Contents):
            print("Assign Target_cell")
            Target_cell = [selected_maze.nrows - 1,i]
            break
    

def Choose_direction(Route_soFar):
    #move from cell to cell by choosing random directions that can be taken from current cell
    #Current_cell_contents = Read_cell(Current_cell)
    global selected_maze
    global Start_cell
    Cells_visited = []
    
    if len(Route_soFar) == 0:
        Cells_visited.append(Start_cell)
    else:
        Cells_visited = Navigate_Maze(Route_soFar, selected_maze)
    
    while True:
        Random_Num = random.randint(0,3)
        if(Random_Num == 0):
            Movement_Direction = "D"
        elif(Random_Num == 1):
            Movement_Direction = "U"
        elif(Random_Num == 2):
            Movement_Direction = "L"
        elif(Random_Num == 3):
            Movement_Direction = "R"
        
        if Movement_Direction in Read_cell(Cells_visited[-1][0], Cells_visited[-1][1], selected_maze):
            break

    
    return Movement_Direction

def genetic_algorithm(maze_address, population, Max_route_length, iterations, mutation_rate, elite_threshold):
    
    global selected_maze
    
    #main genetic algorithm function
    selected_maze = get_excel_maze(maze_address)
    Identify_start_end(selected_maze)
    
    # calls the create_population function and stores result as a list
    gene_pool = []
    gene_pool = create_population(population, selected_maze, Max_route_length)

    best_solution = iterator(gene_pool, iterations, mutation_rate, elite_threshold, selected_maze, Max_route_length)
    
    print(best_solution)
    print(Correct_solution)
    return best_solution
    
def Generate_route(Max_route_length):
    new_route = []
    
    #new_route.append(Start_cell)
    
    for x in range(Max_route_length):
        new_route.append(Choose_direction(new_route))
    
    return new_route

def distance_from_end(selected_cell):
    global Target_cell
    #print(selected_cell, Target_cell)
    Distance_Y = abs(selected_cell[0] - Target_cell[0])
    Distance_X = abs(selected_cell[1] - Target_cell[1])
    
    return(Distance_X + Distance_Y)
    
def distance_from_start(selected_cell):
    global Start_cell
    #print(selected_cell, Target_cell)
    Distance_Y = abs(selected_cell[0] - Start_cell[0])
    Distance_X = abs(selected_cell[1] - Start_cell[1])
    
    return(Distance_X + Distance_Y)

def create_population(population, selected_maze, Max_route_length):

    gene_pool = []

    for x in range(population):
        gene_pool.append(Generate_route(Max_route_length)) 
    return gene_pool

def Navigate_Maze(Route, selected_maze):
    global Start_cell
    Cells_visited = []
    Current_cell = Start_cell
    Cells_visited.append(Current_cell)
    #print(Start_cell)
    
    for x in range(len(Route)):
        if(Route[x] in Read_cell(Current_cell[0], Current_cell[1], selected_maze)):
            if(Route[x] == "D"):
                Next_Cell = [(Current_cell[0] + 1), Current_cell[1]]
            elif(Route[x] == "U"):
                Next_Cell = [(Current_cell[0] - 1), Current_cell[1]]
            elif(Route[x] == "L"):
                Next_Cell = [Current_cell[0], (Current_cell[1] - 1)]
            elif(Route[x] == "R"):
                Next_Cell = [Current_cell[0], (Current_cell[1] + 1)]
            Cells_visited.append(Next_Cell)
            #print(Route[x])
            #print(Next_Cell)
            #print(x, Next_Cell)
        else:
            Next_Cell = Current_cell
        #print(Next_Cell)
        Current_cell = Next_Cell
    
    
    return Cells_visited

def No_newly_visited_cells(Cells_visited):
    
    Cells_visited_before = []
    
    for x in range(len(Cells_visited)):
        if Cells_visited[x] in Cells_visited_before:
            continue
        else:
            Cells_visited_before.append(Cells_visited[x])
    
    return len(Cells_visited_before)

def hasNumbers(inputString):
    return any(char.isdigit() for char in inputString)

def fitness_function(gene_pool, best_solution, selected_maze):
    
    global Correct_solution
    best_solution_value = 0
    
    
    Correct_solution_route = Navigate_Maze(Correct_solution, selected_maze)
    best_solution_value = 0 #-= distance_from_end(best_solution_cells_visited[-1])

    sorted_gene_pool = []
    ranking = []
    
    #best_solution_cells_visited = Navigate_Maze(best_solution, selected_maze)
    #best_solution_value = len(best_solution_cells_visited)
    #best_solution_value = No_newly_visited_cells(best_solution_cells_visited)
    
    # for y in range(len(best_solution_cells_visited) - 1):
        # if (best_solution_cells_visited[y] == Correct_solution_route[y]):
            # best_solution_value += 1
    
    # for y in range(len(best_solution) - 1):
        # if (best_solution[y] == Correct_solution[y]):
            # best_solution_value += 1

    for x in range(len(gene_pool)):
        #print("new individual")
        Cells_visited = Navigate_Maze(gene_pool[x], selected_maze)
        score = 0
        
        # Final_Cell_conents = Read_cell(Cells_visited[-1][0], Cells_visited[-1][1], selected_maze)
        # if(hasNumbers(Final_Cell_conents)):
            # score = int(re.search(r'\d+', Final_Cell_conents).group())
        
        if gene_pool[x] == Correct_solution:
            print("Solution found")
            print(best_solution_value)
            return gene_pool, gene_pool[x]
        
        for y in range(len(Cells_visited) - 1):
           if (Cells_visited[y] == Correct_solution_route[y]):
               score += 1
        
        for y in range(len(gene_pool[x])):
            if (gene_pool[x][y] == Correct_solution[y]):
                score += 1
                
                #for i in range(len(Cells_visited) - 1):
                if(y < len(Cells_visited)):
                    if (Cells_visited[y] == Correct_solution_route[y]):
                        score += 2
        
        
        
        #score -= distance_from_end(Cells_visited[-1])
        #score = len(Cells_visited)
        #score = No_newly_visited_cells(Cells_visited)
        ranking.append(score)

        if score > best_solution_value: # and len(best_solution) >= len(gene_pool[x]):
            best_solution = copy.deepcopy(gene_pool[x])
            best_solution_value = score

    sorted_gene_pool = [x for _,x in sorted(zip(ranking, gene_pool))]
    
    print(best_solution_value)
    
    return sorted_gene_pool, best_solution
    
def iterator(gene_pool, iterations, mutation_rate, elite_threshold, selected_maze, Max_route_length):

    best_solution = gene_pool[0]
    
    # print(Start_cell, Target_cell)
    
    # print(Correct_solution)
    # print(Navigate_Maze(Correct_solution, selected_maze))
    
    for x in range (iterations):
        #x = 0
        #while True:
        print("new iteration", x)
        gene_pool, best_solution = fitness_function(gene_pool, best_solution, selected_maze)
        
        if(best_solution == Correct_solution):
            print("Solution found")
            return best_solution
        
        if(x % 100) == 0:
            print(gene_pool)
        
        gene_pool = mating_function(gene_pool, best_solution, mutation_rate, elite_threshold, selected_maze, Max_route_length)
        print(best_solution)
        print(Navigate_Maze(best_solution, selected_maze))
        #x +=1
    gene_pool, best_solution = fitness_function(gene_pool, best_solution, selected_maze)
    
    print(gene_pool)

    return best_solution


def mating_function(gene_pool, best_solution, mutation_rate, elite_threshold, selected_maze, Max_route_length):

    new_gene_pool = []
    sorted_gene_pool = []
    parent_1 = []
    parent_2 = []

    sorted_gene_pool, best_solution = fitness_function(gene_pool, best_solution, selected_maze)
    print("sorted genepool length", len(sorted_gene_pool))

    for x in range(len(sorted_gene_pool)):
        
        # while True:
            # parent_1 = copy.deepcopy(sorted_gene_pool[random.randint(0, int(len(sorted_gene_pool)*elite_threshold))])
            # parent_2 = copy.deepcopy(sorted_gene_pool[x])
            # if parent_1 != parent_2:
                # break 
        
        parent_1 = copy.deepcopy(sorted_gene_pool[random.randint(0, int(len(sorted_gene_pool)*elite_threshold))])
        parent_2 = copy.deepcopy(sorted_gene_pool[x])
        
        child = breed(parent_1, parent_2, selected_maze)

        child = mutate(child, mutation_rate)
        
        #if child != best_solution:
        new_gene_pool.append(child)
        
        #print(child)
    
    new_gene_pool[-1] = best_solution
    
    sorted_new_gene_pool = fitness_function(new_gene_pool, best_solution, selected_maze)
    replace = round(len(sorted_new_gene_pool) * 0.05)
    
    for x in range(replace):
        sorted_new_gene_pool[-x] = Generate_route(Max_route_length)
    
    gene_pool = copy.deepcopy(new_gene_pool)
    
    return new_gene_pool


def breed(parent_1, parent_2, selected_maze):

    child = []
    dna = []
    cut_points = []
    
    #cut_points.extend([random.randint(0,len(parent_1)), random.randint(0,len(parent_1))])
    cut_points.extend([0, random.randint(1,(len(parent_1)))])
    #cut_points.sort()

    for x in range(cut_points[0], cut_points[1]):
        child.append(parent_1[x])
    
    #for x in range(cut_points[1], len(parent_2)):
    #    child.append(parent_2[x])
    
    
    
    for x in range(cut_points[1], len(parent_1)):
        child.append(Choose_direction(child))

    #print("new Breed")
    #print(parent_1)
    #print(parent_2)
    #print(child)
    
    return child


def mutate(child, mutation_rate):

    for swap in range(len(child)):
        
        if(random.randint(0, 100) < mutation_rate):
            swap_with = random.randint(0, len(child)-1)
            # selected genes will then need to be swapped
            gene_1 = child[swap]
            gene_2 = child[swap_with]
            child[swap] = gene_2
            child[swap_with] = gene_1


    return child

#for testing, the first parameter when calling the algorithm must be the relevant file address of the maze file
#file addresses will vary with the machine it is executed on
genetic_algorithm(r'E:\Users\Daniel\OneDrive\Documents\Uni Work\Final Project Genetic Algorithm\Excel Maze.xls', population = 200, Max_route_length = 55, iterations = 400, mutation_rate = 20, elite_threshold = 0.1)

